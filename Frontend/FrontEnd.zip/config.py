# Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except
# in compliance with the License. A copy of the License is located at
#
# https://aws.amazon.com/apache-2-0/
#
# or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the License.
"Central configuration"
import os

FLASK_SECRET = '\xfd{H\xe5<\x95\xf9\xe3\x96.5\xd1\x01O<!\xd5\xa2\xa0\x9fR"\xa1\xa8'

AWS_REGION = 'us-east-1'
COGNITO_POOL_ID = 'us-east-1_uhGg4MBR8'
COGNITO_CLIENT_ID = '4n92g2mt6jsih730c63lbq5hfm'
COGNITO_CLIENT_SECRET = '145j183fa1bh2go1i39vibvvjne93n96pftvde44jjcrv6etch98'
COGNITO_DOMAIN = 'stt.auth.us-east-1.amazoncognito.com'
BASE_URL = 'https://sttnew-env.eba-gsd3hp9p.us-east-1.elasticbeanstalk.com'

#Backend

API_GW_URL = 'https://4tb8nifz6a.execute-api.us-east-1.amazonaws.com'